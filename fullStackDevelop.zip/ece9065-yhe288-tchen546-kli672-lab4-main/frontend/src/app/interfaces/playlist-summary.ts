export interface PlaylistSummary {
  list_name: string;
  list_creator: string;
  last_modified_date: string;
  number_tracks: string;
  list_rating: string;
  total_play_time: string;
}
