import { Component } from '@angular/core';

@Component({
  selector: 'app-dmcaprocedure',
  templateUrl: './dmcaprocedure.component.html',
  styleUrls: ['./dmcaprocedure.component.css']
})
export class DMCAProcedureComponent {

}
